﻿namespace ZaGeekProject.Migration
{
    public class Class1
    {

    }
}