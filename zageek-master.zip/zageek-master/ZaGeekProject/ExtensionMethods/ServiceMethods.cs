﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ZaGeekProject.Infrastructure.Data;

namespace ZaGeekProject.ExtensionMethods
{
    public static class ServiceMethods
    {
        public static void ServiceInjection(this IServiceCollection services)
        {
            //services.AddScoped<ISchoolService, SchoolService>();
            //services.AddScoped<IEtudiantService, EtudiantService>(); 
            //services.AddScoped<IClasseService, ClasseService>();
            //services.AddScoped<IUserService, UserService>();
        }
        public static void DbContextInjection(this IServiceCollection services, ConfigurationManager configuration)
        {
            services.AddDefaultIdentity<IdentityUser>(options =>
            {
                // options.SignIn.RequireConfirmedEmail = true;
            }).AddEntityFrameworkStores<UserContext>();

            services.AddDbContext<ProjectContext>(options =>
            {
                options.UseSqlite(configuration.GetConnectionString("ProjectSQLite"), sqliteOption =>
                {

                });
            });
            services.AddDbContext<UserContext>(options =>
            {
                options.UseSqlite(configuration.GetConnectionString("UserSQLite"), sqliteOption =>
                {

                });
            });
        }
    }
}
