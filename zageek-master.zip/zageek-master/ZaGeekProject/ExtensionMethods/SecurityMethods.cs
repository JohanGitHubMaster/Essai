﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

namespace ZaGeekProject.ExtensionMethods
{
    public static class SecurityMethods
    {
        public const string POLICY_DEFAULT = "POLICY_DEFAULT";
        public static void SecurityInjection(this IServiceCollection services, ConfigurationManager configuration)
        {
            CorsInjection(services, configuration);
            AuthentificationInjection(services, configuration);
        }
        public static void CorsInjection(this IServiceCollection services, ConfigurationManager configuration)
        {
            services.AddCors(options =>
            {
                options.AddPolicy(POLICY_DEFAULT, item =>
                    item.AllowAnyHeader()
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                );
            });
        }

        public static void AuthentificationInjection(this IServiceCollection services, ConfigurationManager configuration)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                string maClef = configuration["Jwt:Key"];
                options.SaveToken = true;
                options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                {
                    IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(maClef)),
                    ValidateAudience = false,
                    ValidateIssuer = false,
                    ValidateActor = false,
                    ValidateLifetime = true
                };
            }); ;
        }
    }
}
