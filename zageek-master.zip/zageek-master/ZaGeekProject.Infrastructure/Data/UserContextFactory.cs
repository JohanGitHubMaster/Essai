﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace ZaGeekProject.Infrastructure.Data
{
    public class UserContextFactory : IDesignTimeDbContextFactory<UserContext>
    {
        public UserContext CreateDbContext(string[] args)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder()
                .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), @"Settings"))
                .AddJsonFile("appsettings.json", false, true);
            IConfigurationRoot root = builder.Build();

            DbContextOptionsBuilder optionsBuilder = new DbContextOptionsBuilder();

            var connectionString = root.GetConnectionString("UserSQLite");
            var projectMigration = root["ProjetUserMigrations"];
            optionsBuilder.UseSqlite(connectionString, b => b.MigrationsAssembly(projectMigration));

            UserContext context = new UserContext(optionsBuilder.Options);

            return context;
        }
    }
}
