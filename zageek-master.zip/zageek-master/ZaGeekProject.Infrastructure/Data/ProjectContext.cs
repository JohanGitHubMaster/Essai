﻿using Microsoft.EntityFrameworkCore;

namespace ZaGeekProject.Infrastructure.Data
{
    public class ProjectContext : DbContext
    {
        public ProjectContext()
        {
        }

        public ProjectContext(DbContextOptions<ProjectContext> options)
            : base(options)
        {
        }
    }
}
