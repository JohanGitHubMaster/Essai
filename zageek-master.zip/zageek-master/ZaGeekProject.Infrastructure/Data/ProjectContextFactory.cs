﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using ZaGeekProject.Infrastructure.Data;

namespace School.Infrastructure.Data
{
    public class ProjectContextFactory : IDesignTimeDbContextFactory<ProjectContext>
    {
        public ProjectContext CreateDbContext(string[] args)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder()
                .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), @"Settings"))
                .AddJsonFile("appsettings.json", false, true);
            IConfigurationRoot root = builder.Build();

            DbContextOptionsBuilder<ProjectContext> optionsBuilder = new DbContextOptionsBuilder<ProjectContext>();

            var connectionString = root.GetConnectionString("ProjectSQLite");
            var projectMigration = root["ProjetMigrations"];
            optionsBuilder.UseSqlite(connectionString, b => b.MigrationsAssembly(projectMigration));

            ProjectContext context = new ProjectContext(optionsBuilder.Options);

            return context;
        }
    }
}
